# RxJs Ejercicios
Una lista de ejercicios de RxJs para practicar un poco.

## Nota:
Todos estos ejercicios los resolvemos en mi curso de ReactiveX que lo puedes encontrar en mi sitio web al menor precio posible:

[fernando-herrera.com](https://fernando-herrera.com/#/home)
